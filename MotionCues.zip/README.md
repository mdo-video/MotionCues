# Motion Cues (Android)

App anti nausea per l'uso del telefono in auto, ispirata ai "Vehicle Motion Cues" di iPhone.
Puntini sui bordi dello schermo che scorrono in base ad accelerazioni, frenate e curve.

L'APK viene compilato automaticamente da GitHub Actions (file `.github/workflows/build.yml`).
Dopo ogni push: scheda **Actions** -> ultima esecuzione -> **Artifacts** -> `MotionCues-APK`.
