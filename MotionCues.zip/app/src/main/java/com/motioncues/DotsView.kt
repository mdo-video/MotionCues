package com.motioncues

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max

/**
 * Puntini lungo i bordi dello schermo che scorrono in base al movimento dell'auto.
 */
class DotsView(context: Context) : View(context) {

    var sensitivity = 1f
    var dotRadiusDp = 5f
    var opacity = 0.8f

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }

    private var fr = 0f   // accelerazione laterale filtrata
    private var ff = 0f   // accelerazione avanti/indietro filtrata
    private var tx = 0f
    private var ty = 0f
    private var ox = 0f
    private var oy = 0f
    private var last = 0L

    /** right: accelerazione verso destra, fwd: accelerazione in avanti (m/s^2) */
    fun setMotion(right: Float, fwd: Float) {
        fr += 0.25f * (right - fr)
        ff += 0.25f * (fwd - ff)
        val k = sensitivity * 14f * density
        val lim = 70f * density
        tx = (-fr * k).coerceIn(-lim, lim)
        ty = (ff * k).coerceIn(-lim, lim)
        postInvalidateOnAnimation()
    }

    private fun wrap(v: Float, len: Float): Float {
        val r = v % len
        return if (r < 0) r + len else r
    }

    private fun dot(c: Canvas, x: Float, y: Float, r: Float) {
        c.drawCircle(x, y, r * 1.35f, edge)
        c.drawCircle(x, y, r, fill)
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        val a = 1f - exp(-dt * 9f)
        ox += (tx - ox) * a
        oy += (ty - oy) * a

        val w = width.toFloat()
        val h = height.toFloat()
        val m = 16f * density
        val sp = 56f * density
        val r = dotRadiusDp * density
        val lenX = w - 2 * m
        val lenY = h - 2 * m
        if (lenX <= 0 || lenY <= 0) return

        fill.alpha = (opacity * 255).toInt()
        edge.alpha = (opacity * 110).toInt()

        val ny = max(2, (lenY / sp).toInt())
        val stepY = lenY / ny
        for (i in 0 until ny) {
            val y = m + wrap(i * stepY + oy, lenY)
            dot(c, m, y, r)
            dot(c, w - m, y, r)
        }
        val nx = max(2, (lenX / sp).toInt())
        val stepX = lenX / nx
        for (i in 0 until nx) {
            val x = m + wrap(i * stepX + ox, lenX)
            dot(c, x, m, r)
            dot(c, x, h - m, r)
        }

        if (abs(tx - ox) > 0.3f || abs(ty - oy) > 0.3f) postInvalidateOnAnimation()
    }
}
