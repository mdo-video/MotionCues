package com.motioncues

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import kotlin.math.sqrt

class OverlayService : Service(), SensorEventListener {

    companion object {
        const val PREFS = "cfg"
        private const val ACTION_STOP = "com.motioncues.STOP"
        private const val CHANNEL = "motion_cues"

        @Volatile
        var running = false

        fun start(c: Context) {
            c.startForegroundService(Intent(c, OverlayService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var sm: SensorManager
    private lateinit var prefs: SharedPreferences
    private var view: DotsView? = null

    private var gx = 0f
    private var gy = 9.81f
    private var gz = 0f

    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Motion Cues", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (view == null) {
            addOverlay()
            registerSensors()
        }
        running = true
        return START_STICKY
    }

    private fun goForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Motion Cues attivo")
            .setContentText("I puntini anti nausea sono visibili")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_notification), "Spegni", stopPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        val v = DotsView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        view = v
        applyPrefs()
    }

    private fun applyPrefs() {
        val v = view ?: return
        val sens = prefs.getInt("sens", 50)
        val size = prefs.getInt("size", 40)
        val alpha = prefs.getInt("alpha", 80)
        v.sensitivity = 0.3f + sens / 100f * 1.7f
        v.dotRadiusDp = 3f + size / 100f * 6f
        v.opacity = 0.2f + alpha / 100f * 0.8f
        v.invalidate()
    }

    private fun registerSensors() {
        val grav = sm.getDefaultSensor(Sensor.TYPE_GRAVITY)
        val lin = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        if (grav != null && lin != null) {
            sm.registerListener(this, grav, SensorManager.SENSOR_DELAY_GAME)
            sm.registerListener(this, lin, SensorManager.SENSOR_DELAY_GAME)
        } else {
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GRAVITY -> {
                gx = e.values[0]; gy = e.values[1]; gz = e.values[2]
            }
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                process(e.values[0], e.values[1], e.values[2])
            }
            Sensor.TYPE_ACCELEROMETER -> {
                gx += 0.08f * (e.values[0] - gx)
                gy += 0.08f * (e.values[1] - gy)
                gz += 0.08f * (e.values[2] - gz)
                process(e.values[0] - gx, e.values[1] - gy, e.values[2] - gz)
            }
        }
    }

    /**
     * Converte l'accelerazione del telefono in accelerazione "dell'auto":
     * avanti/indietro e destra/sinistra, ipotizzando che chi guarda lo schermo
     * sia rivolto nel senso di marcia (telefono con lo schermo verso di lui).
     */
    private fun process(ax: Float, ay: Float, az: Float) {
        val gn = sqrt(gx * gx + gy * gy + gz * gz)
        if (gn < 1f) return
        val ux = gx / gn
        val uy = gy / gn
        val uz = gz / gn

        // direzione "avanti" orizzontale = -z del telefono senza la parte verticale
        var hx = uz * ux
        var hy = uz * uy
        var hz = -1f + uz * uz
        var hn = sqrt(hx * hx + hy * hy + hz * hz)
        if (hn < 0.25f) {
            // telefono quasi piatto: avanti = lato alto dello schermo
            hx = -uy * ux
            hy = 1f - uy * uy
            hz = -uy * uz
            hn = sqrt(hx * hx + hy * hy + hz * hz)
            if (hn < 0.01f) return
        }
        hx /= hn; hy /= hn; hz /= hn

        // destra = avanti x su
        val rx = hy * uz - hz * uy
        val ry = hz * ux - hx * uz
        val rz = hx * uy - hy * ux

        val fwd = ax * hx + ay * hy + az * hz
        val right = ax * rx + ay * ry + az * rz
        view?.setMotion(right, fwd)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        sm.unregisterListener(this)
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        running = false
        super.onDestroy()
    }
}
