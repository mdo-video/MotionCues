package com.motioncues

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var toggle: Button
    private lateinit var perm: Button
    private lateinit var status: TextView

    private val prefs by lazy { getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE) }
    private val dp by lazy { resources.displayMetrics.density }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * dp).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(label("Motion Cues", 26f, true))
        root.addView(
            label(
                "Puntini ai bordi dello schermo che si muovono con l'auto, " +
                    "per ridurre la nausea quando usi il telefono in macchina.",
                15f, false
            )
        )

        status = label("", 15f, true)
        root.addView(status)

        perm = Button(this).apply {
            text = "1. Consenti la visualizzazione sopra le altre app"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        root.addView(perm)

        toggle = Button(this).apply {
            setOnClickListener {
                if (OverlayService.running) {
                    OverlayService.stop(this@MainActivity)
                } else if (Settings.canDrawOverlays(this@MainActivity)) {
                    OverlayService.start(this@MainActivity)
                }
                postDelayed({ refresh() }, 400)
            }
        }
        root.addView(toggle)

        root.addView(label("Impostazioni", 20f, true))
        addSeek(root, "Sensibilità", "sens", 50)
        addSeek(root, "Dimensione puntini", "size", 40)
        addSeek(root, "Opacità", "alpha", 80)

        root.addView(
            label(
                "Consiglio: se il telefono la ferma da solo, disattiva l'ottimizzazione " +
                    "batteria per questa app. Puoi anche aggiungere il tasto \"Anti nausea\" " +
                    "alle impostazioni rapide per accenderla al volo.",
                13f, false
            )
        )

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        perm.visibility = if (canDraw) View.GONE else View.VISIBLE
        toggle.isEnabled = canDraw
        toggle.text = if (OverlayService.running) "Spegni i puntini" else "2. Accendi i puntini"
        status.text = when {
            !canDraw -> "Permesso mancante"
            OverlayService.running -> "Attivo"
            else -> "Spento"
        }
    }

    private fun label(t: String, size: Float, bold: Boolean) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(0, (10 * dp).toInt(), 0, (6 * dp).toInt())
    }

    private fun addSeek(root: LinearLayout, title: String, key: String, def: Int) {
        root.addView(label(title, 15f, false))
        root.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt(key, def)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt(key, p).apply()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }
}
