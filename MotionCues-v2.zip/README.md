# Motion Cues (Android)

App anti nausea per l'uso del telefono in auto, ispirata ai "Vehicle Motion Cues" di iPhone.
Puntini sui bordi dello schermo che scorrono in base ad accelerazioni, frenate e curve.

- Attivazione manuale (pulsante, tile delle impostazioni rapide) o automatica ("in veicolo").
- Notifica persistente con tasto STOP visibile senza espanderla.
- Aggiornamenti: l'APK e' firmato con una chiave fissa (`app/motioncues.p12`), quindi si installa
  sopra la versione precedente senza disinstallare. Tieni la repo privata.

L'APK viene compilato da GitHub Actions a ogni push.
Download fisso dell'ultima versione: **Releases -> MotionCues.apk**
(`/releases/latest/download/MotionCues.apk`). In alternativa: Actions -> ultima esecuzione -> Artifacts.
