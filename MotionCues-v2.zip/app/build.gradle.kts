plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Numero progressivo della build su GitHub: fa crescere versionCode a ogni compilazione,
// cosi' Android accetta l'aggiornamento sopra la versione gia' installata.
val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0

android {
    namespace = "com.motioncues"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.motioncues"
        minSdk = 26
        targetSdk = 34
        versionCode = 100 + runNumber
        versionName = "2.$runNumber"
    }

    // Chiave di firma FISSA (file app/motioncues.p12): stessa firma a ogni build,
    // quindi gli aggiornamenti si installano senza disinstallare.
    signingConfigs {
        create("fixed") {
            storeFile = file("motioncues.p12")
            storeType = "pkcs12"
            storePassword = "motioncues"
            keyAlias = "motioncues"
            keyPassword = "motioncues"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
