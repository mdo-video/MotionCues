package com.motioncues

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionResult
import com.google.android.gms.location.DetectedActivity

/** Riceve gli eventi "sei salito / sceso da un veicolo" e accende / spegne i puntini. */
class ActivityReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (!ActivityTransitionResult.hasResult(intent)) return
        val result = ActivityTransitionResult.extractResult(intent) ?: return
        val prefs = context.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("auto", false)) return

        for (e in result.transitionEvents) {
            if (e.activityType != DetectedActivity.IN_VEHICLE) continue
            if (e.transitionType == ActivityTransition.ACTIVITY_TRANSITION_ENTER) {
                if (!OverlayService.running && Settings.canDrawOverlays(context)) {
                    try {
                        OverlayService.start(context, auto = true)
                    } catch (_: Exception) {
                    }
                }
            } else if (e.transitionType == ActivityTransition.ACTIVITY_TRANSITION_EXIT) {
                // spegne solo se i puntini li ha accesi l'automatico (non se li hai accesi tu a mano)
                if (OverlayService.running && prefs.getBoolean("auto_started", false)) {
                    OverlayService.stop(context)
                }
            }
        }
    }
}
