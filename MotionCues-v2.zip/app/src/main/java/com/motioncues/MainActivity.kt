package com.motioncues

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.sin

class MainActivity : AppCompatActivity() {

    private val bodyStyle = com.google.android.material.R.style.TextAppearance_Material3_BodyMedium

    private lateinit var preview: DotsView
    private lateinit var mainButton: MaterialButton
    private lateinit var status: TextView
    private lateinit var autoSwitch: MaterialSwitch
    private lateinit var permHint: TextView
    private val swatches = ArrayList<View>()
    private var suppressSwitch = false

    private val handler = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.uptimeMillis()
    private val demo = object : Runnable {
        override fun run() {
            val t = (SystemClock.uptimeMillis() - t0) / 1000f
            // accelerazioni finte (curve e frenate) per mostrare i puntini in anteprima
            preview.setAcceleration(2.6f * sin(t * 0.85f), 2.2f * sin(t * 0.5f + 1.3f))
            handler.postDelayed(this, 16)
        }
    }

    private val prefs by lazy { getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun col(a: Int, def: Int) = MaterialColors.getColor(this, a, def)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val surface = col(MR.attr.colorSurface, Color.WHITE)
        val onSurface = col(MR.attr.colorOnSurface, Color.BLACK)
        val onVariant = col(MR.attr.colorOnSurfaceVariant, Color.DKGRAY)
        val cardBg = col(MR.attr.colorSurfaceContainerHigh, Color.LTGRAY)
        val primary = col(MR.attr.colorPrimary, Color.BLUE)
        val primaryContainer = col(MR.attr.colorPrimaryContainer, Color.LTGRAY)
        val onPrimaryContainer = col(MR.attr.colorOnPrimaryContainer, Color.BLACK)
        val outline = col(MR.attr.colorOutlineVariant, Color.GRAY)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(32))
        }

        // ---------- intestazione ----------
        root.addView(TextView(this).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_HeadlineLarge)
            setTextColor(onSurface)
            this.text = "Motion Cues"
            setPadding(dp(8), 0, dp(8), 0)
        })
        root.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            this.text = "Puntini ai bordi dello schermo che si muovono con l'auto, per ridurre la nausea quando usi il telefono da passeggero."
            setPadding(dp(8), dp(4), dp(8), dp(16))
        })

        // ---------- anteprima + pulsante principale ----------
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        status = TextView(this).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_LabelLarge)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(primaryContainer)
            }
            setTextColor(onPrimaryContainer)
        }
        hero.addView(status, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        // finto schermo scuro con righe di testo, per vedere i puntini "in azione"
        val phone = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#12161C"))
            }
            clipToOutline = true
        }
        val lines = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(56), dp(40), dp(56), dp(24))
        }
        val widths = intArrayOf(70, 100, 90, 100, 60, 85)
        for (w in widths) {
            lines.addView(View(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.parseColor("#2A313B"))
                }
            }, LinearLayout.LayoutParams(0, dp(10)).apply { bottomMargin = dp(14) }.also {
                it.width = (w * 1.8f * resources.displayMetrics.density).toInt().coerceAtMost(dp(230))
            })
        }
        phone.addView(lines, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        preview = DotsView(this).apply { applyFrom(prefs) }
        phone.addView(preview, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        hero.addView(phone, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(230)
        ).apply { bottomMargin = dp(16) })

        mainButton = MaterialButton(this).apply {
            textSize = 16f
            cornerRadius = dp(28)
            insetTop = 0
            insetBottom = 0
            setOnClickListener { onMainButton() }
        }
        hero.addView(mainButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
        ))
        permHint = TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), 0)
            this.text = "Serve il permesso di mostrare i puntini sopra le altre app."
        }
        hero.addView(permHint)
        root.addView(card(hero, cardBg))

        // ---------- attivazione automatica ----------
        val autoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val autoTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        autoTexts.addView(TextView(this).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
            setTextColor(onSurface)
            this.text = "Attivazione automatica"
        })
        autoTexts.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            this.text = "Si accende da sola quando il telefono capisce che sei in un veicolo e si spegne quando scendi."
        })
        autoRow.addView(autoTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        autoSwitch = MaterialSwitch(this).apply {
            setOnCheckedChangeListener { _, on ->
                if (suppressSwitch) return@setOnCheckedChangeListener
                if (on) enableAuto() else disableAuto()
            }
        }
        autoRow.addView(autoSwitch)
        root.addView(card(autoRow, cardBg))

        // ---------- aspetto ----------
        val look = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(12))
        }
        look.addView(TextView(this).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
            setTextColor(onSurface)
            this.text = "Aspetto"
            setPadding(0, 0, 0, dp(4))
        })
        addSlider(look, "Sensibilità", "sens", 50, onVariant)
        addSlider(look, "Dimensione", "size", 40, onVariant)
        addSlider(look, "Opacità", "alpha", 80, onVariant)
        addSlider(look, "Densità", "dens", 50, onVariant)
        look.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            this.text = "Colore"
            setPadding(0, dp(12), 0, dp(8))
        })
        val sw = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in DotsView.PALETTE.indices) {
            val v = View(this).apply {
                setOnClickListener {
                    prefs.edit().putInt("col", i).apply()
                    preview.applyFrom(prefs)
                    updateSwatches(primary, outline)
                }
            }
            swatches.add(v)
            sw.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) })
        }
        look.addView(sw)
        updateSwatches(primary, outline)
        root.addView(card(look, cardBg))

        // ---------- consigli ----------
        val tips = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        tips.addView(TextView(this).apply {
            setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
            setTextColor(onSurface)
            this.text = "Perché funzioni sempre"
        })
        tips.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            this.text = "Se il telefono ferma l'app da solo (o l'attivazione automatica non parte), togli le restrizioni di batteria" +
                (if (isXiaomi()) " e consenti l'avvio automatico." else ".")
            setPadding(0, dp(4), 0, dp(8))
        })
        val tipButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tipButtons.addView(MaterialButton(
            this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
        ).apply {
            this.text = "Batteria"
            setOnClickListener { openBatterySettings() }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        if (isXiaomi()) {
            tipButtons.addView(MaterialButton(
                this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
            ).apply {
                this.text = "Avvio automatico"
                setOnClickListener { openXiaomiAutostart() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        tips.addView(tipButtons)
        root.addView(card(tips, cardBg))

        root.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(onVariant)
            gravity = Gravity.CENTER
            this.text = "Versione ${versionName()}"
            setPadding(0, dp(8), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(surface)
            isFillViewport = true
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // rinnova la registrazione del rilevamento automatico (utile dopo un aggiornamento)
        if (prefs.getBoolean("auto", false) && hasActivityPermission()) {
            AutoMode.enable(this)
        }
    }

    override fun onStart() {
        super.onStart()
        OverlayService.listener = { runOnUiThread { refresh() } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.post(demo)
    }

    override fun onPause() {
        handler.removeCallbacks(demo)
        super.onPause()
    }

    override fun onStop() {
        OverlayService.listener = null
        super.onStop()
    }

    // ------------------------------------------------------------------

    private fun card(content: View, bg: Int): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(28).toFloat()
        cardElevation = 0f
        strokeWidth = 0
        setCardBackgroundColor(bg)
        addView(content)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
    }

    private fun addSlider(parent: LinearLayout, title: String, key: String, def: Int, labelColor: Int) {
        parent.addView(TextView(this).apply {
            setTextAppearance(bodyStyle)
            setTextColor(labelColor)
            this.text = title
            setPadding(0, dp(8), 0, 0)
        })
        parent.addView(Slider(this).apply {
            valueFrom = 0f
            valueTo = 100f
            stepSize = 1f
            value = prefs.getInt(key, def).toFloat()
            addOnChangeListener { _, v, fromUser ->
                if (fromUser) {
                    prefs.edit().putInt(key, v.toInt()).apply()
                    preview.applyFrom(prefs)
                }
            }
        })
    }

    private fun updateSwatches(primary: Int, outline: Int) {
        val sel = prefs.getInt("col", 0)
        for (i in swatches.indices) {
            swatches[i].background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(DotsView.PALETTE[i])
                setStroke(dp(if (i == sel) 4 else 1), if (i == sel) primary else outline)
            }
        }
    }

    private fun onMainButton() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (OverlayService.running) OverlayService.stop(this) else OverlayService.start(this)
        mainButton.postDelayed({ refresh() }, 400)
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        val auto = prefs.getBoolean("auto", false)
        permHint.visibility = if (canDraw) View.GONE else View.VISIBLE
        mainButton.text = when {
            !canDraw -> "Consenti il permesso"
            OverlayService.running -> "Ferma i puntini"
            else -> "Accendi i puntini"
        }
        status.text = when {
            OverlayService.running -> "● Attivo"
            auto -> "Automatico · in attesa del viaggio"
            else -> "Spento"
        }
        suppressSwitch = true
        autoSwitch.isChecked = auto
        suppressSwitch = false
    }

    // ---------- attivazione automatica ----------

    private fun hasActivityPermission(): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    private fun enableAuto() {
        if (!hasActivityPermission()) {
            requestPermissions(arrayOf(Manifest.permission.ACTIVITY_RECOGNITION), 2)
        } else {
            activateAuto()
        }
    }

    private fun activateAuto() {
        prefs.edit().putBoolean("auto", true).apply()
        AutoMode.enable(this) { ok ->
            runOnUiThread {
                if (!ok) {
                    prefs.edit().putBoolean("auto", false).apply()
                    Toast.makeText(
                        this, "Rilevamento non disponibile (servono i Google Play services)", Toast.LENGTH_LONG
                    ).show()
                } else if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Ricorda di consentire anche il permesso overlay", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }
        refresh()
    }

    private fun disableAuto() {
        prefs.edit().putBoolean("auto", false).apply()
        AutoMode.disable(this)
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                activateAuto()
            } else {
                Toast.makeText(this, "Senza il permesso l'automatico non può partire", Toast.LENGTH_LONG).show()
                refresh()
            }
        }
    }

    // ---------- utilità ----------

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (_: Exception) {
        "?"
    }

    private fun isXiaomi(): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (_: Exception) {
            openAppDetails()
        }
    }

    private fun openXiaomiAutostart() {
        try {
            startActivity(
                Intent().setComponent(
                    ComponentName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.autostart.AutoStartManagementActivity"
                    )
                )
            )
        } catch (_: Exception) {
            openAppDetails()
        }
    }

    private fun openAppDetails() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }
}
