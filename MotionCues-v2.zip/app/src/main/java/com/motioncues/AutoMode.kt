package com.motioncues

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionRequest
import com.google.android.gms.location.DetectedActivity

/**
 * Attivazione automatica: Google (Activity Recognition) avvisa l'app quando il telefono
 * rileva che sei in un veicolo (entra / esce), come l'opzione "Solo in veicolo" di iPhone.
 */
object AutoMode {

    private const val ACTION = "com.motioncues.ACTIVITY_TRANSITION"

    private fun pending(c: Context): PendingIntent {
        val i = Intent(c, ActivityReceiver::class.java).setAction(ACTION)
        // deve essere MUTABLE: i Google Play services ci aggiungono i dati dell'evento
        return PendingIntent.getBroadcast(
            c, 10, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
    }

    fun enable(c: Context, onResult: (Boolean) -> Unit = {}) {
        try {
            val transitions = listOf(
                ActivityTransition.Builder()
                    .setActivityType(DetectedActivity.IN_VEHICLE)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_ENTER)
                    .build(),
                ActivityTransition.Builder()
                    .setActivityType(DetectedActivity.IN_VEHICLE)
                    .setActivityTransition(ActivityTransition.ACTIVITY_TRANSITION_EXIT)
                    .build()
            )
            ActivityRecognition.getClient(c.applicationContext)
                .requestActivityTransitionUpdates(ActivityTransitionRequest(transitions), pending(c))
                .addOnSuccessListener { onResult(true) }
                .addOnFailureListener { onResult(false) }
        } catch (e: Exception) {
            onResult(false)
        }
    }

    fun disable(c: Context) {
        try {
            ActivityRecognition.getClient(c.applicationContext)
                .removeActivityTransitionUpdates(pending(c))
        } catch (_: Exception) {
        }
    }
}
