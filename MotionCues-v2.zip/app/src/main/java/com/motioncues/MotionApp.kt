package com.motioncues

import android.app.Application
import com.google.android.material.color.DynamicColors

class MotionApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}
