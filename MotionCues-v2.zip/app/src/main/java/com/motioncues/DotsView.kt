package com.motioncues

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.tanh
import java.util.Random

/**
 * Campo di puntini lungo i 4 bordi dello schermo, ispirato ai "Vehicle Motion Cues" di iPhone.
 *
 * - Ogni puntino ha dimensione e "profondita'" diverse (parallasse): i piu' grandi si muovono di piu',
 *   cosi' lo spostamento si vede anche a veicolo fermo nella manovra (niente griglia uniforme).
 * - Spostamento immediato proporzionale all'accelerazione (sensazione di inerzia) +
 *   scorrimento tipo "flusso ottico" che continua e si spegne piano dopo la manovra.
 * - I puntini escono dal bordo e rientrano dall'altra parte senza "salti" visibili.
 *
 * L'accelerazione arriva gia' nel sistema di coordinate dello schermo (x destra, y giu'),
 * quindi funziona uguale in verticale e in orizzontale.
 */
class DotsView(context: Context) : View(context) {

    companion object {
        val PALETTE = intArrayOf(
            Color.WHITE,
            Color.BLACK,
            Color.parseColor("#FFC107"),
            Color.parseColor("#4FC3F7"),
            Color.parseColor("#FF7043")
        )
        private const val BAND_DP = 46f      // profondita' della fascia di puntini dal bordo
        private const val OUT_DP = 16f       // fuori schermo, per rientro senza salti
        private const val FADE_DP = 18f      // dissolvenza sul lato interno della fascia
        private const val PAD_DP = 24f       // margine fuori schermo lungo il bordo
    }

    var sensitivity = 1.3f
    var dotRadiusDp = 5.4f
    var opacity = 0.85f
    var spacingDp = 50f

    private val density = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)

    private class Dot(
        val edge: Int,      // 0 sinistra, 1 destra, 2 alto, 3 basso
        val u: Float,       // posizione lungo il bordo (0..1)
        val v: Float,       // posizione nella fascia (0..1)
        val size: Float,    // fattore dimensione
        val depth: Float    // fattore parallasse
    )

    private var dots: List<Dot> = emptyList()
    private var builtW = 0
    private var builtH = 0
    private var builtSpacing = 0f

    // accelerazione (m/s^2) negli assi schermo
    private var tAx = 0f
    private var tAy = 0f
    private var sAx = 0f
    private var sAy = 0f

    // spostamento immediato e flusso (dp)
    private var offX = 0f
    private var offY = 0f
    private var flowX = 0f
    private var flowY = 0f
    private var velX = 0f
    private var velY = 0f

    private var last = 0L

    init {
        setPalette(0)
    }

    fun setPalette(idx: Int) {
        val c = PALETTE[idx.coerceIn(0, PALETTE.size - 1)]
        val lum = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        fill.color = c
        halo.color = if (lum > 0.6f) Color.BLACK else Color.WHITE
    }

    /** Legge le preferenze (stesse chiavi usate dalla schermata impostazioni). */
    fun applyFrom(p: SharedPreferences) {
        val sens = p.getInt("sens", 50)
        val size = p.getInt("size", 40)
        val alpha = p.getInt("alpha", 80)
        val dens = p.getInt("dens", 50)
        sensitivity = 0.4f + sens / 100f * 1.8f
        dotRadiusDp = 3f + size / 100f * 6f
        opacity = 0.25f + alpha / 100f * 0.75f
        spacingDp = 72f - dens * 0.45f
        setPalette(p.getInt("col", 0))
        rebuildIfNeeded()
        invalidate()
    }

    /**
     * Accelerazione del veicolo proiettata sullo schermo (x destra, y giu'), in m/s^2.
     * I puntini si muovono nel verso opposto, come il paesaggio visto da chi viaggia.
     */
    fun setAcceleration(ax: Float, ay: Float) {
        tAx = ax
        tAy = ay
        postInvalidateOnAnimation()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildIfNeeded()
    }

    private fun rebuildIfNeeded() {
        if (width == 0 || height == 0) return
        if (width == builtW && height == builtH && spacingDp == builtSpacing && dots.isNotEmpty()) return
        builtW = width
        builtH = height
        builtSpacing = spacingDp
        val rnd = Random(42)
        val list = ArrayList<Dot>()
        val wDp = width / density
        val hDp = height / density
        for (edge in 0..3) {
            val lenDp = if (edge <= 1) hDp else wDp
            val n = maxOf(3, (lenDp / spacingDp).roundToInt())
            for (i in 0 until n) {
                val u = ((i + 0.1f + rnd.nextFloat() * 0.8f) / n)
                // sequenza "aurea": distribuisce bene i puntini nella profondita' della fascia
                val v = (((i * 0.618034f) + edge * 0.27f) % 1f)
                val size = 0.65f + rnd.nextFloat() * 0.7f
                val depth = 0.7f + (size - 0.65f) / 0.7f * 0.7f
                list.add(Dot(edge, u, v, size, depth))
            }
        }
        dots = list
    }

    private fun wrap(v: Float, lo: Float, hi: Float): Float {
        val span = hi - lo
        val r = (v - lo) - floor((v - lo) / span) * span
        return lo + r
    }

    /** Avanza la simulazione. Ritorna true se c'e' ancora movimento da animare. */
    private fun step(dt: Float): Boolean {
        val dz = 0.25f
        val ax = if (abs(tAx) < dz) 0f else tAx - Math.signum(tAx) * dz
        val ay = if (abs(tAy) < dz) 0f else tAy - Math.signum(tAy) * dz

        val f = 1f - exp(-dt / 0.15f)
        sAx += (ax - sAx) * f
        sAy += (ay - sAy) * f

        val k = sensitivity * 24f
        val lim = 80f
        val targetX = lim * tanh(-sAx * k / lim)
        val targetY = lim * tanh(-sAy * k / lim)
        val g = 1f - exp(-dt * 8f)
        offX += (targetX - offX) * g
        offY += (targetY - offY) * g

        val gain = sensitivity * 22f
        val decay = exp(-dt / 2.2f)
        velX = velX * decay - sAx * gain * dt
        velY = velY * decay - sAy * gain * dt
        flowX += velX * dt
        flowY += velY * dt
        // evita che i valori crescano all'infinito
        if (abs(flowX) > 100000f) flowX %= 1000f
        if (abs(flowY) > 100000f) flowY %= 1000f

        return abs(sAx) > 0.01f || abs(sAy) > 0.01f ||
            abs(targetX - offX) > 0.2f || abs(targetY - offY) > 0.2f ||
            abs(velX) > 0.5f || abs(velY) > 0.5f
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceIn(0.001f, 0.05f)
        last = now
        val moving = step(dt)

        rebuildIfNeeded()
        val w = width.toFloat()
        val h = height.toFloat()
        val band = BAND_DP * density
        val out = OUT_DP * density
        val fade = FADE_DP * density
        val pad = PAD_DP * density
        val baseR = dotRadiusDp * density
        val totX = (offX + flowX) * density
        val totY = (offY + flowY) * density

        for (d in dots) {
            val vertical = d.edge <= 1
            val len = if (vertical) h else w
            val spanA = len + 2 * pad

            val alongMove = if (vertical) totY else totX
            val a = wrap(d.u * spanA - pad + d.depth * alongMove, -pad, len + pad)

            val acrossMove = when (d.edge) {
                0 -> totX
                1 -> -totX
                2 -> totY
                else -> -totY
            }
            val c0 = -out + d.v * (band + out)
            val cr = wrap(c0 + d.depth * acrossMove, -out, band)
            val fadeF = ((band - cr) / fade).coerceIn(0f, 1f)

            val x: Float
            val y: Float
            when (d.edge) {
                0 -> { x = cr; y = a }
                1 -> { x = w - cr; y = a }
                2 -> { x = a; y = cr }
                else -> { x = a; y = h - cr }
            }
            val r = baseR * d.size
            if (x < -r || x > w + r || y < -r || y > h + r) continue

            val al = opacity * fadeF
            halo.alpha = (al * 110f).toInt()
            fill.alpha = (al * 255f).toInt()
            c.drawCircle(x, y, r * 1.35f, halo)
            c.drawCircle(x, y, r, fill)
        }

        if (moving) postInvalidateOnAnimation()
    }
}
