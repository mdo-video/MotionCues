package com.motioncues

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Display
import android.view.Surface
import android.view.WindowManager
import android.widget.RemoteViews
import kotlin.math.hypot
import kotlin.math.sqrt

class OverlayService : Service(), SensorEventListener {

    companion object {
        const val PREFS = "cfg"
        private const val ACTION_STOP = "com.motioncues.STOP"
        private const val ACTION_REPOST = "com.motioncues.REPOST"
        private const val EXTRA_AUTO = "auto"
        private const val CHANNEL = "motion_cues"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        /** Chiamato (sul thread principale) quando il servizio parte o si ferma. */
        @Volatile
        var listener: (() -> Unit)? = null

        fun start(c: Context, auto: Boolean = false) {
            c.startForegroundService(
                Intent(c, OverlayService::class.java).putExtra(EXTRA_AUTO, auto)
            )
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, OverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private lateinit var sm: SensorManager
    private lateinit var nm: NotificationManager
    private lateinit var prefs: SharedPreferences
    private var view: DotsView? = null
    private var sensing = false

    private var gx = 0f
    private var gy = 9.81f
    private var gz = 0f

    // direzione "su" sullo schermo (x destra, y su), smussata
    private var upX = 0f
    private var upY = 1f
    private val tmp = FloatArray(2)

    private val prefListener =
        SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> view?.applyFrom(prefs) }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> unregisterSensors()
                Intent.ACTION_SCREEN_ON -> if (view != null) registerSensors()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Motion Cues", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REPOST -> {
                // la notifica e' stata scartata dall'utente: la rimettiamo subito
                if (view != null) nm.notify(NOTIF_ID, buildNotification())
                return START_STICKY
            }
        }
        if (!goForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent != null) {
            prefs.edit().putBoolean("auto_started", intent.getBooleanExtra(EXTRA_AUTO, false)).apply()
        }
        if (view == null) {
            addOverlay()
            registerSensors()
        }
        running = true
        listener?.invoke()
        return START_STICKY
    }

    private fun stopPendingIntent(): PendingIntent = PendingIntent.getService(
        this, 1,
        Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val repost = PendingIntent.getService(
            this, 2,
            Intent(this, OverlayService::class.java).setAction(ACTION_REPOST),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopPi = stopPendingIntent()

        // Vista personalizzata: il tasto STOP e' visibile anche a notifica compatta (senza espanderla)
        val rv = RemoteViews(packageName, R.layout.notification_bar).apply {
            setTextViewText(R.id.n_title, getString(R.string.notif_title))
            setTextViewText(R.id.n_text, getString(R.string.notif_text))
            setOnClickPendingIntent(R.id.n_stop, stopPi)
        }

        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setStyle(Notification.DecoratedCustomViewStyle())
            .setCustomContentView(rv)
            .setCustomBigContentView(rv)
            .setContentIntent(open)
            .setDeleteIntent(repost)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            // copia di sicurezza standard (visibile espandendo la notifica)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_notification),
                    getString(R.string.notif_stop), stopPi
                ).build()
            )
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    private fun goForeground(): Boolean {
        return try {
            val n = buildNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, n)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun addOverlay() {
        val v = DotsView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(v, lp)
        view = v
        v.applyFrom(prefs)
    }

    private fun registerSensors() {
        if (sensing) return
        sensing = true
        val grav = sm.getDefaultSensor(Sensor.TYPE_GRAVITY)
        val lin = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        if (grav != null && lin != null) {
            sm.registerListener(this, grav, SensorManager.SENSOR_DELAY_GAME)
            sm.registerListener(this, lin, SensorManager.SENSOR_DELAY_GAME)
        } else {
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
            }
        }
    }

    private fun unregisterSensors() {
        if (!sensing) return
        sensing = false
        sm.unregisterListener(this)
    }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GRAVITY -> {
                gx = e.values[0]; gy = e.values[1]; gz = e.values[2]
            }
            Sensor.TYPE_LINEAR_ACCELERATION -> {
                process(e.values[0], e.values[1], e.values[2])
            }
            Sensor.TYPE_ACCELEROMETER -> {
                gx += 0.08f * (e.values[0] - gx)
                gy += 0.08f * (e.values[1] - gy)
                gz += 0.08f * (e.values[2] - gz)
                process(e.values[0] - gx, e.values[1] - gy, e.values[2] - gz)
            }
        }
    }

    private fun displayRotation(): Int {
        val dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        return dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
    }

    /** Porta un vettore dagli assi del telefono agli assi dello schermo (x destra, y SU). */
    private fun toScreen(vx: Float, vy: Float, rot: Int) {
        when (rot) {
            Surface.ROTATION_90 -> { tmp[0] = -vy; tmp[1] = vx }
            Surface.ROTATION_180 -> { tmp[0] = -vx; tmp[1] = -vy }
            Surface.ROTATION_270 -> { tmp[0] = vy; tmp[1] = -vx }
            else -> { tmp[0] = vx; tmp[1] = vy }
        }
    }

    /**
     * Converte l'accelerazione del telefono in accelerazione "dell'auto" (avanti/indietro, destra/sinistra)
     * ipotizzando che chi guarda lo schermo sia rivolto nel senso di marcia, poi la proietta sullo schermo
     * usando la direzione "su" reale (funziona in verticale, orizzontale e a telefono inclinato).
     */
    private fun process(ax: Float, ay: Float, az: Float) {
        val gn = sqrt(gx * gx + gy * gy + gz * gz)
        if (gn < 1f) return
        val ux = gx / gn
        val uy = gy / gn
        val uz = gz / gn

        // direzione "avanti" orizzontale = -z del telefono senza la parte verticale
        var hx = uz * ux
        var hy = uz * uy
        var hz = -1f + uz * uz
        var hn = sqrt(hx * hx + hy * hy + hz * hz)
        if (hn < 0.25f) {
            // telefono quasi piatto: avanti = lato alto dello schermo
            hx = -uy * ux
            hy = 1f - uy * uy
            hz = -uy * uz
            hn = sqrt(hx * hx + hy * hy + hz * hz)
            if (hn < 0.01f) return
        }
        hx /= hn; hy /= hn; hz /= hn

        // destra = avanti x su
        val rx = hy * uz - hz * uy
        val ry = hz * ux - hx * uz
        val rz = hx * uy - hy * ux

        val fwd = ax * hx + ay * hy + az * hz
        val right = ax * rx + ay * ry + az * rz

        // direzione "su" dello schermo dalla gravita' (ignorata se il telefono e' quasi piatto)
        val rot = displayRotation()
        toScreen(gx, gy, rot)
        val gh = hypot(tmp[0], tmp[1])
        if (gh > 0.35f * gn) {
            val nx = tmp[0] / gh
            val ny = tmp[1] / gh
            upX += 0.1f * (nx - upX)
            upY += 0.1f * (ny - upY)
            val un = hypot(upX, upY)
            if (un > 0.01f) {
                upX /= un
                upY /= un
            }
        }

        // accelerazione del veicolo sullo schermo: right * destra_schermo + fwd * su_schermo
        // destra_schermo (y su) = (upY, -upX); in coordinate schermo con y verso il basso:
        val sx = right * upY + fwd * upX
        val sy = right * upX - fwd * upY
        view?.setAcceleration(sx, sy)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        unregisterSensors()
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        view?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        view = null
        running = false
        listener?.invoke()
        super.onDestroy()
    }
}
