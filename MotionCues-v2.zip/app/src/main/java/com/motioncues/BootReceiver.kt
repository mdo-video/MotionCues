package com.motioncues

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Dopo un riavvio o un aggiornamento dell'app, riattiva il rilevamento automatico. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean("auto", false)) {
            AutoMode.enable(context)
        }
    }
}
